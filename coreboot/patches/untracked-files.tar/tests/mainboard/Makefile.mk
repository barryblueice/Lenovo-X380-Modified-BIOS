# SPDX-License-Identifier: GPL-2.0-only

tests-y += x380-autopatcher-test
x380-autopatcher-test-syssrcs += tests/mainboard/x380-autopatcher-test.c
x380-autopatcher-test-syssrcs += src/mainboard/lenovo/sklkbl_thinkpad/variants/x380_yoga/autopatcher.c
x380-autopatcher-test-cflags += -Isrc
x380-autopatcher-test-no_test_framework := y
