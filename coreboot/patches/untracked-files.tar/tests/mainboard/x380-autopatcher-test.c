/* SPDX-License-Identifier: GPL-2.0-only */

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <mainboard/lenovo/sklkbl_thinkpad/variants/x380_yoga/autopatcher.h>

struct fake_ec {
	uint8_t data[1024];
	unsigned int reads, writes, calls;
	unsigned int fail_call;
	int discard_writes;
	uint8_t last_command, last_tx[3];
};

static int transfer(void *context, uint8_t command, const uint8_t *tx,
		    size_t tx_size, uint8_t *rx, size_t rx_size)
{
	struct fake_ec *ec = context;
	unsigned int address;

	ec->calls++;
	if (ec->fail_call == ec->calls)
		return X380_AP_TIMEOUT;
	assert(tx[0] < 8 && tx[1] < 128);
	address = tx[0] * 128 + tx[1];
	ec->last_command = command;
	memcpy(ec->last_tx, tx, tx_size);
	if (command == 0x5e) {
		assert(tx_size == 2 && rx_size == 1 && rx);
		*rx = ec->data[address];
		ec->reads++;
	} else {
		assert(command == 0x5f && tx_size == 3 && rx_size == 0);
		if (!ec->discard_writes)
			ec->data[address] = tx[2];
		ec->writes++;
	}
	return X380_AP_OK;
}

static void reset(struct fake_ec *ec)
{
	memset(ec, 0, sizeof(*ec));
	memset(ec->data, 0xa5, sizeof(ec->data));
}

static void test_addresses(void)
{
	struct fake_ec ec;
	struct x380_ap_io io = { &ec, transfer };
	uint8_t value;

	reset(&ec);
	for (unsigned int bank = 0x54; bank <= 0x57; bank++) {
		for (unsigned int offset = 0; offset < 256; offset++) {
			assert(x380_ap_read(&io, bank, offset, &value) == 0);
			assert(value == 0xa5);
			assert(ec.last_command == 0x5e);
			assert(ec.last_tx[0] == (bank - 0x54) * 2 + offset / 128);
			assert(ec.last_tx[1] == offset % 128);
		}
	}
	assert(x380_ap_write(&io, 0x57, 255, 0x42) == 0);
	assert(ec.last_command == 0x5f && ec.last_tx[0] == 7);
	assert(ec.last_tx[1] == 127 && ec.last_tx[2] == 0x42);
	reset(&ec);
	for (unsigned int i = 0; i < 8; i++) {
		assert(x380_ap_write(&io, 0x5c, i, 0xff) == 0);
		assert(x380_ap_read(&io, 0x5c, i, &value) == 0 && value == 0xff);
	}
	assert(x380_ap_read(&io, 0x53, 0, &value) == X380_AP_INVALID);
	assert(x380_ap_read(&io, 0x58, 0, &value) == X380_AP_INVALID);
	assert(x380_ap_write(&io, 0x57, 256, 0) == X380_AP_INVALID);
	assert(x380_ap_read(&io, 0x5c, 8, &value) == X380_AP_INVALID);
	assert(x380_ap_write(&io, 0x154, 0, 0) == X380_AP_INVALID);
	assert(x380_ap_read(&io, 0x54, 0, NULL) == X380_AP_INVALID);
	assert(x380_ap_read(NULL, 0x54, 0, &value) == X380_AP_INVALID);
	io.transfer = NULL;
	assert(x380_ap_write(&io, 0x54, 0, 0) == X380_AP_INVALID);
	assert(ec.calls == 0);
}

static void test_snapshot(void)
{
	struct fake_ec ec;
	struct x380_ap_io io = { &ec, transfer };
	uint8_t dump[X380_AP_DUMP_SIZE];

	reset(&ec);
	assert(x380_ap_snapshot(&io, dump) == 0);
	assert(ec.reads == 1024 && ec.writes == 0);
	for (unsigned int i = 0; i < sizeof(dump); i++)
		assert(dump[i] == (i < 1024 ? 0xa5 : 0xff));
	reset(&ec);
	ec.fail_call = 19;
	assert(x380_ap_snapshot(&io, dump) == X380_AP_TIMEOUT);
	assert(ec.calls == 19 && ec.writes == 0);
}

static void test_template(const uint8_t expected[X380_AP_BANK_SIZE])
{
	struct fake_ec ec;
	struct x380_ap_io io = { &ec, transfer };
	uint8_t backup[X380_AP_BANK_SIZE];
	size_t completed = 123;

	reset(&ec);
	assert(x380_ap_apply_template(&io, backup, &completed) == 0);
	assert(completed == 256 && ec.reads == 512 && ec.writes == 256);
	assert(memcmp(ec.data + 768, expected, 256) == 0);
	for (unsigned int i = 0; i < sizeof(backup); i++)
		assert(backup[i] == 0xa5);
	for (unsigned int i = 0; i < 768; i++)
		assert(ec.data[i] == 0xa5);
	reset(&ec);
	ec.fail_call = 17;
	assert(x380_ap_apply_template(&io, backup, &completed) == X380_AP_TIMEOUT);
	assert(completed == 0 && ec.writes == 0);
	reset(&ec);
	ec.fail_call = 256 + 10;
	assert(x380_ap_apply_template(&io, backup, &completed) == X380_AP_TIMEOUT);
	assert(completed == 9 && ec.writes == 9 && ec.calls == 266);
	reset(&ec);
	ec.discard_writes = 1;
	assert(x380_ap_apply_template(&io, backup, &completed) == X380_AP_VERIFY);
	assert(completed == 256);
	reset(&ec);
	ec.fail_call = 512 + 6;
	assert(x380_ap_apply_template(&io, backup, &completed) == X380_AP_TIMEOUT);
	assert(ec.calls == 518 && completed == 256);
	reset(&ec);
	assert(x380_ap_apply_template(&io, NULL, &completed) == X380_AP_INVALID);
	assert(completed == 0 && ec.calls == 0);
	assert(x380_ap_apply_template(&io, backup, NULL) == X380_AP_INVALID);
	assert(ec.calls == 0);
}

int main(int argc, char **argv)
{
	uint8_t expected[X380_AP_BANK_SIZE];
	const char *fixture = argc > 1 ? argv[1] : "tests/data/x380-autopatcher-bank57.hex";
	FILE *file = fopen(fixture, "rb");
	unsigned int byte;

	assert(file);
	for (unsigned int i = 0; i < sizeof(expected); i++) {
		assert(fscanf(file, "%2x", &byte) == 1);
		expected[i] = byte;
	}
	assert(fscanf(file, "%2x", &byte) == EOF);
	fclose(file);
	test_addresses();
	test_snapshot();
	test_template(expected);
	puts("PASS: X380 mapping, no-op bank, snapshot, template and failure paths");
	return 0;
}
